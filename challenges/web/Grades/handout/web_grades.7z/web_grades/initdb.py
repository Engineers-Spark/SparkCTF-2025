import sqlite3
from hashlib import sha256


def init_db():
    conn = sqlite3.connect('grades.db')
    c = conn.cursor()

    
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            email TEXT NOT NULL,
            reset_token TEXT
        )
    ''')

    
    c.execute('''
        CREATE TABLE IF NOT EXISTS grades (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            grade TEXT NOT NULL,
            FOREIGN KEY (username) REFERENCES users (username)
        )
    ''')

    
    admin_password = sha256('REDACTED'.encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO users (username, password, email) VALUES (?, ?, ?)', ('admin', admin_password, 'admin@example.com'))

    
    user_password = sha256('REDACTED'.encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO users (username, password, email) VALUES (?, ?, ?)', ('user1', user_password, 'user1@example.com'))

    
    c.execute('INSERT OR IGNORE INTO grades (username, grade) VALUES (?, ?)', ('user1', 'A'))
    c.execute('INSERT OR IGNORE INTO grades (username, grade) VALUES (?, ?)', ('user1', 'B'))
    c.execute('INSERT OR IGNORE INTO grades (username, grade) VALUES (?, ?)', ('admin', 'A'))

    
    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db()
    print("Database initialized successfully.")
